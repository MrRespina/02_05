const express = require('express');
const User = require('../schemas/user');

const router = express.Router();

// User.find({})로 모든 사용자 찾고
// mongoose.html 랜더링 시 users 변수도 넣어줌.
router.get('/',async (req,res,next)=>{

    try{
        const users = await User.find({});
        res.render('mongoose',{users});
    }catch(err){
        console.log(err);
        next(err);
    }

});

module.exports = router;