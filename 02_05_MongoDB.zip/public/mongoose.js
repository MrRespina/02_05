// 사용자 이름 눌렀을 시 댓글 로딩
document.querySelectorAll('#user-list tr').forEach((el)=>{
    el.addEventListener('click',()=>{
        const id = el.querySelector('td').textContent;
        getComment(id);
    });
});

// 사용자 로딩
async function getUser(){
    try{
        const res = await axios.get('/users');
        const users = res.data;
        console.log(users);

        const tbody = document.querySelector('#user-list tbody');
        tbody.innerHTML = '';
        users.map((user) =>{
            const row = document.createElement('tr');
            row.addEventListener('click',()=>{
                getComment(user._id);
            });

            let td = document.createElement('td');
            td.textContent = user._id;
            row.appendChild(td);

            td = document.createElement('td');
            td.textContent = user.name;
            row.appendChild(td);

            td = document.createElement('td');
            td.textContent = user.age;
            row.appendChild(td);

            td = document.createElement('td');
            td.textContent = user.married ? '기혼':'미혼';
            row.appendChild(td);

            tbody.appendChild(row);

        });
    }catch(err){
        console.error(err);
    }
}

// 댓글 로딩
async function getComment(id){

    try{

        const res = await axios.get(`/users/${id}/comments`);
        const comments = res.data;
        const tbody = document.querySelector('#comment-list tbody');
        tbody.innerHTML='';
        comments.map((comment)=>{

            const row = document.createElement('tr');

            let td = document.createElement('td');
            td.textContent = comment._id;
            row.appendChild(td);

            td = document.createElement('td');
            td.textContent = comment.commenter.name;
            row.appendChild(td);

            td = document.createElement('td');
            td.textContent = comment.comment;
            row.appendChild(td);

            const edit = document.createElement('button');
            edit.textContent = '수정';
            edit.addEventListener('click',async ()=>{
                const newComment = prompt('바꿀내용 입력');
                if(!newComment){
                    return alert('내용을 반드시 입력할 것!');
                }
                try{
                    await axios.patch(`/comments/${comment._id}`,
                        {comment:newComment});
                    getComment(id);
                }catch(err){
                    console.error(err);
                }
            });

            const remove = document.createElement('button');
            remove.textContent = '삭제';
            remove.addEventListener('click',async ()=>{
                try{
                    await axios.delete(`/comments/${comment._id}`);
                    getComment(id);
                }catch(err){
                    console.error(err);
                }

            });

            // 버튼 추가
            td = document.createElement('td');
            td.appendChild(edit);
            row.appendChild(td);

            td = document.createElement('td');
            td.appendChild(remove);
            row.appendChild(td);

            tbody.appendChild(row);

        });

    }catch(err){
        console.error(err);
    }

}

// 사용자 등록
document.getElementById('user-form').addEventListener('submit', async (e) => {

    // a 태그나, button 태그는 누르게 되면
    // href를 통해 이동하거나, 지정한 주소로 이동하는데,
    // 창이 새로고침하여 실행하는 것을
    // preventDefault 를 통해 막아줌 
    e.preventDefault();
    const name = e.target.name.value;
    const age = e.target.age.value;
    const married = e.target.married.checked;
    if (!name) {
        return alert('이름을 입력하세요');
    }
    if (!age) {
        return alert('나이를 입력하세요');
    }
    try {
        await axios.post('/users', {name, age, married});
        getUser();
    } catch (err) {        
        console.error(err);
    }
    e.target.name.value = '';
    e.target.age.value = '';
    e.target.married.checked = false;
});

// 댓글 등록 시
document.getElementById('comment-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = e.target.id.value;
    const comment = e.target.comment.value;
    if (!id) {
        return alert('아이디를 입력하세요');
    }
    if (!comment) {
        return alert('댓글을 입력하세요');
    }
    try {
        await axios.post('/comments', {id, comment});
        getComment(id);
    } catch (err) {
        console.error(err);
    }
    e.target.id.value = '';
    e.target.comment.value = '';
});